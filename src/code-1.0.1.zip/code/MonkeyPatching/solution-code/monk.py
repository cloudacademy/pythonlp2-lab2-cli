#CODE1: Define a new class named A in the monk module
class A: 
     def func(self): 
          print('func() is being called')