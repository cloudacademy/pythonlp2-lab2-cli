#CODE1: Define a new class named A in the monk module
